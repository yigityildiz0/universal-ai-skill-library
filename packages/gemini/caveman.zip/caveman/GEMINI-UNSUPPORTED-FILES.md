# Files not included in the Gemini app copy

The Gemini app accepts text, code (.py/.sh), data and document/image files only. These files exist in the complete source (Gemini/gemini-cli-skills.zip or the full-source ZIP) and must be run locally when needed:

- agents/check-profile-scope.mjs
- agents/compile.mjs
- agents/delegate/caveman-delegate-mcp.mjs
- agents/delegate/portable-process.mjs
- agents/delegate/portable-process.test.mjs
- agents/drift-report.mjs
- agents/probe-installed.mjs
- agents/version.mjs
- modules/activation-rule.mjs
- modules/caveman-explore/tests/skill-file.test.mjs
- modules/caveman-learn/tests/index.js
- modules/caveman-learn/tests/skill-file.test.mjs
- modules/compile.mjs
- modules/verbs-gate.mjs
