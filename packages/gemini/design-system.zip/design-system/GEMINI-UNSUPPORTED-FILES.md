# Files not included in the Gemini app copy

The Gemini app accepts text, code (.py/.sh), data and document/image files only. These files exist in the complete source (Gemini/gemini-cli-skills.zip or the full-source ZIP) and must be run locally when needed:

- scripts/embed-tokens.cjs
- scripts/generate-tokens.cjs
- scripts/validate-tokens.cjs
- yigit/scripts/embed-tokens.cjs
- yigit/scripts/generate-tokens.cjs
- yigit/scripts/validate-tokens.cjs
