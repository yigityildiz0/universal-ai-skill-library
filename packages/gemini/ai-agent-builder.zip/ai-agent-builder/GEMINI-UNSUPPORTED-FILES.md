# Files not included in the Gemini app copy

The Gemini app accepts text, code (.py/.sh), data and document/image files only. These files exist in the complete source (Gemini/gemini-cli-skills.zip or the full-source ZIP) and must be run locally when needed:

- modules/chatgpt-apps/scripts/scaffold_node_ext_apps.mjs
- modules/codex-agent-dev-kit/scripts/check_codex_agent_kit.ps1
- modules/mcp-builder/scripts/example_evaluation.xml
- modules/writing-skills/graphviz-conventions.dot
- modules/writing-skills/render-graphs.js
