# Files not included in the Gemini app copy

The Gemini app accepts text, code (.py/.sh), data and document/image files only. These files exist in the complete source (Gemini/gemini-cli-skills.zip or the full-source ZIP) and must be run locally when needed:

- modules/playwright-interactive/assets/playwright-small.svg
- modules/systematic-debugging/condition-based-waiting-example.ts
