# Files not included in the Gemini app copy

The Gemini app accepts text, code (.py/.sh), data and document/image files only. These files exist in the complete source (Gemini/gemini-cli-skills.zip or the full-source ZIP) and must be run locally when needed:

- scripts/extract-colors.cjs
- scripts/inject-brand-context.cjs
- scripts/sync-brand-to-tokens.cjs
- scripts/validate-asset.cjs
- yigit/scripts/extract-colors.cjs
- yigit/scripts/inject-brand-context.cjs
- yigit/scripts/sync-brand-to-tokens.cjs
- yigit/scripts/validate-asset.cjs
