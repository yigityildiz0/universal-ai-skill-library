# the user's customized slides workflow

> the user's earlier customized copy of `slides-workflow`, kept alongside the current upstream skill. Paths below are relative to this `yigit/` folder.
> Original trigger scope: Sunum anlatısı, slayt düzeni ve çıktı bütünlüğü için ek sunum iş akışı uygula.

# Slides

Design a narrative first and a visual deck second. Resolve skill-dir to this folder before using bundled search and validation tools.

## Workflow

1. Define audience, decision, time limit, slide count, evidence, brand, and output format.
2. Write a one-sentence narrative and a slide-by-slide argument before layout.
3. Choose one strategy and layout family.
4. Use one message per slide; move supporting detail to notes or appendix.
5. Build from design tokens and reusable slide patterns.
6. Turn data into a stated insight, not decoration.
7. Validate sequence, evidence, readability, overflow, contrast, and export behavior.

Read only the needed reference:

- references/slide-strategies.md for narrative structures;
- references/layout-patterns.md for composition;
- references/copywriting-formulas.md for concise persuasion;
- references/html-template.md for HTML deck structure;
- references/create.md for the complete creation flow.

## Search the bundled slide library

~~~text
python "<skill-dir>/scripts/search-slides.py" "investor pitch" -d strategy
python "<skill-dir>/scripts/search-slides.py" "metrics dashboard" -d layout
python "<skill-dir>/scripts/search-slides.py" "problem urgency" -d copy --json
~~~

Use returned patterns as candidates; adapt them to the audience and evidence.

Other bundled helpers (run from the target project root):

- `scripts/generate-slide.py --json <content.json> --tokens <tokens.css> --output <deck.html>` embeds token CSS; package any font/image URLs in those tokens separately for offline use. Defaults and `--demo` content are illustrative, not verified claims.
- `scripts/html-token-validator.py <deck.html>` checks inline token usage; `scripts/slide-token-validator.py` is its compatibility entrypoint. Neither proves visual, keyboard or contrast quality.
- `scripts/fetch-background.py --help` provides optional background-search guidance using `data/slide-backgrounds.csv`; review its actual options before network access.

## Implementation rules

- Use semantic design tokens for color, type, spacing, and chart styling.
- Keep text within safe margins and test the smallest intended viewport.
- Provide alt text or a text summary for charts and meaningful images.
- Label axes, units, dates, samples, and sources.
- Prefer editable text and vector shapes over text baked into images.
- Keep animation optional, purposeful, and reduced-motion compatible.

## Output contract

Provide:

- narrative and slide outline;
- final deck or implementation files;
- source list and chart-data provenance;
- speaker notes when requested;
- validation results for overflow, links, contrast, and export.

## Guardrails

- Do not invent metrics, testimonials, citations, or customer logos.
- Do not shrink body text to force excessive copy onto one slide.
- Do not use a chart without stating its takeaway.
- Do not hardcode a provider, model, or host-specific path.
