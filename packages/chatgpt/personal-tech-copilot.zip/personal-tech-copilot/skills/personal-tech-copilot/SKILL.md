---
name: personal-tech-copilot
description: "Personal technology help: diagnoses and fixes Windows, macOS, Android and iPhone problems, apps, device setup, compatibility, networking, displays, peripherals, storage, backups and cross-device workflows; read-only PC health checks for slow computers (disk, RAM, CPU, startup); tech purchase compatibility. Turkish triggers: nasıl yaparım, neden çalışmıyor, hata veriyor, bilgisayar yavaş, kurulum, ayar, uyumlu mu, telefon veya PC sorunu. More triggers: disk dolu, RAM, başlangıç programları, Wi-Fi, yazıcı, yedekleme."
---

# Personal Tech Copilot

Own the practical device/workflow problem from exact identity through verification. Prefer the shortest safe path that preserves data and allows rollback.

Read [references/troubleshooting-and-setup.md](references/troubleshooting-and-setup.md). Use `computer-health-check` module for broad Windows system health, `purchase-advisor` skill (`market-pricing-analysis` module) for a purchase decision, `research-analyst` skill (`quick-research` module) or `research-analyst` skill (`deep-research` module) for current app/product discovery at the requested depth, and a security skill for malware, credential, or account-compromise concerns.

## Workflow

1. **Identify the stack.** Resolve device/model or hardware class, OS/app/firmware version, connection path, account context, region/language, accessories/adapters, and exact symptom/error. Use screenshots and system information when available; never infer a model from appearance alone.
2. **Establish desired state and constraints.** Determine what should work, what changed, urgency, data-loss tolerance, privacy needs, warranty/managed-device limits, and which devices are physically available.
3. **Verify changing facts.** For menus, compatibility, feature availability, support status, firmware, subscription limits, or current product specifications, inspect current official documentation first. Use community reports only for reproducible failure patterns and label them.
4. **Protect the user.** Before account resets, encryption changes, firmware updates, partitioning, registry changes, network resets, device removal, factory reset, or destructive troubleshooting, verify backup/recovery credentials and state the rollback path.
5. **Test from low risk upward.** Confirm basics and reproduce → isolate device/account/network/app → change one variable → test → record result → proceed. Do not dump a long list of unrelated fixes.
6. **Use decision checkpoints.** After each meaningful step state the expected result and what the next branch is if it succeeds or fails.
7. **Close the loop.** Confirm the real workflow works end to end, not merely that an error disappeared. Document the final state and any settings changed.

## App and peripheral decisions

- For an app recommendation, verify the exact platform and region, current store
  availability, genuinely usable free export, paywall/subscription limits,
  watermark, account requirement, privacy, permissions, offline behavior, and
  output format. “Free download” is not the same as free completion or export.
- For a mouse, keyboard, controller, or other peripheral remap, verify the exact
  model and revision, vendor software support, onboard-memory limits, per-app
  profiles, firmware/OS restrictions, and whether the original function remains
  accessible. Do not infer programmability from a similar model.

## Evidence and screenshot discipline

- Match instructions to the exact version and interface language. If labels differ, give both Turkish and English menu names when useful.
- Treat vendor support pages as authoritative for declared compatibility and procedure, but not automatically for comparative quality or every real-world limitation.
- Do not rely on stale forum instructions for current menus. When official steps and observed UI disagree, state the version/date and use the screenshot as evidence of the actual state.
- Never claim a device supports a standard merely because a similarly named model does.

## Safety and privacy

- Never request passwords, recovery keys, one-time codes, full serial numbers, private IP/public IP exposure, or account tokens in chat. Ask the user to enter secrets locally.
- Do not disable security controls, expose remote services to the internet, install unsigned drivers, run opaque scripts, or delete data as a convenience step.
- For remote access, prefer authenticated encrypted vendor or well-maintained solutions, least privilege, MFA, device allowlists, and explicit session termination. Explain any port exposure and safer alternative.
- For smart-home and shared accounts, clarify home ownership, permissions, guest access, automations, privacy, and what happens when the internet or hub fails.
- If an action may affect warranty, encryption, photos/files, account access, or all devices in an account, warn before the step and require a recovery path.

## Output

Start with the likely cause or best setup choice. Then give numbered actions in the exact order to try, with expected result/checkpoint and a rollback note for consequential changes. End with the smallest diagnostic detail needed if the issue remains.

## PC health check

For a slow or unstable computer, or a request to check disk, RAM, CPU, startup load or errors, run the read-only `computer-health-check` module first; ask before any cleanup, install, update or configuration change.

## Module map

Open only the module(s) the request needs and read the module file completely before acting. Several modules may combine in one task.

| Module | Use when | File |
|---|---|---|
| `computer-health-check` | Perform a bounded, read-only health check of a Windows, macOS, or Linux computer, covering storage, memory pressure, CPU activity, startup load, battery where available,… | [MODULE.md](modules/computer-health-check/MODULE.md) |
