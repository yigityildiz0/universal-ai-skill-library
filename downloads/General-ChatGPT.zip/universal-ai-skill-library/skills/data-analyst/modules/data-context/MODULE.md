# Module: data-context

> Part of the `data-analyst` skill. Paths below are relative to this module folder (`modules/data-context/`).
> Original trigger scope: Create or repair a durable data context containing schema, grain, metric definitions, lineage, ownership, freshness, and quality caveats. Use for data dictionary, metric definitions, semantic layer, analytics context, schema documentation, or data onboarding.

# Data Context

Make data meaning discoverable before analysis or automation.

1. Inventory datasets/tables, owners, grain, keys, update cadence, and access constraints.
2. Define metrics with numerator, denominator, filters, time window, source, owner, and known caveats.
3. Document relationships and transformations without pretending unverified lineage is factual.
4. Keep an index concise and link deep detail by subject area.
5. Review stale definitions, duplicates, and conflicting names before creating a new metric.

Do not scan unauthorized systems or preserve secrets. A data context is documentation, not a guarantee that the underlying data is correct.
